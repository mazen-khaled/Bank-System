/*
 ============================================================================
 Module      : Server.c
 Author      : Mazen Khaled
 Description : C-Project
 ============================================================================
 */
#include "Server.h"
#include <stdio.h>
#include<string.h>

ST_accountsDB_t accountsDB[255] =
{{1165.0, RUNNING, "8989374615436851"},
 {16516.0, BLOCKED, "3165416543523552"},
 {500.0, RUNNING, "4659834531654688"},
 {2165.0, BLOCKED, "1453132315655215"},
 {5445.0, RUNNING, "2315668531235648"},
 {100000.0, BLOCKED, "2154586513216866"}
};
ST_accountsDB_t *accountDB_ptr;

int count = 0;

ST_transaction_t transactionDB [255]= {0};

EN_transState_t recieveTransactionData(ST_transaction_t* transData) {
	//Finding the account
	for(int x=0 ; x<254 ; x++){
		//check the account id
		if ( *(transData->cardHolderData.primaryAccountNumber) == *(accountsDB[x].primaryAccountNumber) ) {
			accountDB_ptr = &accountsDB[x];
			//Check the account state
			if (accountsDB[x].state == BLOCKED) {
				return DECLINED_STOLEN_CARD;
			}

			if (transData->terminalData.transAmount > accountsDB[x].balance) {
				return DECLINED_INSUFFECIENT_FUND;
			}
			else {
				accountsDB[x].balance = accountsDB[x].balance - (transData->terminalData.transAmount);
				return APPROVED;
			}
		}
	}
	//The account is not found
	return FRAUD_CARD;
}

EN_serverError_t isValidAccount(ST_cardData_t* cardData) {
	for(int x=0 ; x<254 ; x++){
		if (!strcmp( &(accountsDB[x].primaryAccountNumber) , &(cardData->primaryAccountNumber) ) )
			return SERVER_OK;//0
	}
	return ACCOUNT_NOT_FOUND;//3
}

EN_serverError_t isBlockedAccount() {
	if (accountDB_ptr->state == BLOCKED)
		return BLOCKED_ACCOUNT;//5
	else
		return SERVER_OK;//0
}

EN_serverError_t isAmountAvailable(ST_terminalData_t* termData) {
	if (termData->transAmount > accountDB_ptr->balance) {
		return LOW_BALANCE;//4
	}
	else
		return SERVER_OK;//0
}

EN_serverError_t saveTransaction(ST_transaction_t* transData) {
	strcpy(transactionDB[count].cardHolderData.primaryAccountNumber, transData->cardHolderData.primaryAccountNumber);
	strcpy(transactionDB[count].cardHolderData.cardHolderName, transData->cardHolderData.cardHolderName);
	strcpy(transactionDB[count].cardHolderData.cardExpirationDate, transData->cardHolderData.cardExpirationDate);

	transactionDB[count].terminalData.maxTransAmount = transData->terminalData.maxTransAmount;

	strcpy(transactionDB[count].terminalData.transactionDate,transData->terminalData.transactionDate);

	transactionDB[count].terminalData.transAmount = transData->terminalData.transAmount;

	transactionDB[count].transactionSequenceNumber = ++(transData->transactionSequenceNumber);

	transactionDB[count].transState = transData->transState;

	return 0;
}

void listSavedTransactions(void) {
	printf("#############################################\n");
	printf("Transaction Sequence: %lf \n", transactionDB[count].transactionSequenceNumber);
	printf("Transaction Date: %s \n", transactionDB[count].terminalData.transactionDate);
	printf("Transaction Amount: %f \n", transactionDB[count].terminalData.transAmount);
	printf("Transaction State: %d \n", transactionDB[count].transState);
	printf("Terminal Max Amount: %f \n", transactionDB[count].terminalData.maxTransAmount);
	printf("Card holder Name: %s \n", transactionDB[count].cardHolderData.cardHolderName);
	printf("PAN: %s \n", transactionDB[count].cardHolderData.primaryAccountNumber);
	printf("Card Expiration Date: %s \n", transactionDB[count].cardHolderData.cardExpirationDate);
	printf("#############################################");
	count++;
}
