/*
 ============================================================================
 Module      : Terminal.c
 Author      : Mazen Khaled
 Description : C-Project
 ============================================================================
 */

#include <stdio.h>
#include "Terminal.h"

EN_terminalError_t getTransactionDate(ST_terminalData_t* termData) {
	int DD = 0 ,MM = 0;

	//Check for the input format
	if( isdigit(termData->transactionDate[0]) &&
			isdigit(termData->transactionDate[1]) &&
			isdigit(termData->transactionDate[3]) &&
			isdigit(termData->transactionDate[4]) &&
			termData->transactionDate[2] == '/' &&
			termData->transactionDate[5] == '/' &&
			termData->transactionDate[10] == '\0'){
		//calculating the input day
		DD = 10 * ((termData->transactionDate[0]) - '0') + ((termData->transactionDate[1]) - '0');
		if (DD <= 31) {
			//calculating the input Month
			MM = 10 * ((termData->transactionDate[3]) - '0') + ((termData->transactionDate[1]) - '4');
			if (MM <= 12) {
				return TERMINAL_OK;
			}
			else
				return WRONG_DATE;
		}
		else
			return WRONG_DATE;
	}
	else
		return WRONG_DATE;
}

EN_terminalError_t isCardExpired(ST_cardData_t* cardData, ST_terminalData_t* termData) {
	//Compare Months and Years
	if ( ((10 * (cardData->cardExpirationDate[3] - '0') + (cardData->cardExpirationDate[4] - '0')) >= (10 * (termData->transactionDate[8] - '0') + (termData->transactionDate[9] - '0')))){
		if(((10 * (cardData->cardExpirationDate[0] - '0') + (cardData->cardExpirationDate[1] - '0')) >= (10 * (termData->transactionDate[3] - '0') + (termData->transactionDate[4] - '0'))))
			return TERMINAL_OK;
		else
			return EXPIRED_CARD;
	}
	else
		return EXPIRED_CARD;
}

EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData) {
	// Checking the input transaction Amount.
	if (termData->transAmount <= 0)
		return INVALID_AMOUNT;
	else
		return TERMINAL_OK;
}

EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData) {
	//checking the max amount in the account
	if (termData->maxTransAmount < termData->transAmount) return EXCEED_MAX_AMOUNT;
	else return TERMINAL_OK;
}

EN_terminalError_t setMaxAmount(ST_terminalData_t* termData, float maxAmount) {
	if (maxAmount > 0) {
		termData->maxTransAmount = maxAmount;
		return TERMINAL_OK;
	}
	else return INVALID_MAX_AMOUNT;
}
