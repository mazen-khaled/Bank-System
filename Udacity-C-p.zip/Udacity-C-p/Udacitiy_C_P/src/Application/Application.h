/*
 ============================================================================
 Header      : Application.h
 Author      : Mazen Khaled
 Description : C-Project
 ============================================================================
 */

#ifndef APPLICATION_H_
#define APPLICATION_H_

#include "..\Server\Server.h"

void appStart(void);

#endif /* APPLICATION_H_ */
