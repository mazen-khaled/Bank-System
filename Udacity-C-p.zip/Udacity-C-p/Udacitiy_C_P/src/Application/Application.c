/*
 ============================================================================
 Module      : Application.c
 Author      : Mazen Khaled
 Copyright   : Your copyright notice
 Description : C-Project
 ============================================================================
 */

#include "Application.h"
#include <stdio.h>

// DataBase: 156551.0 - RUNNING - 4659834531654688

ST_cardData_t myCardData = {"MazenKhaledSalahEldin","4659834531654688","05/21"}; //Expired card
ST_terminalData_t terminalData = {5500.0,10000.0,"14/03/2022"};
ST_transaction_t transcationData =
{{"MazenKhaledSalahEldin","4659834531654688","05/21"}
 ,{5500.0,10000.0,"14/03/2022"}
 ,APPROVED
 ,3};


void appStart(void){

	if(getCardHolderName(&myCardData) == CARD_OK
		&& getCardExpiryDate(&myCardData) == CARD_OK
		&& getCardPAN(&myCardData) == CARD_OK ){

		if(getTransactionDate(&terminalData) == TERMINAL_OK
		 && isCardExpired(&myCardData, &terminalData)== TERMINAL_OK
		 && getTransactionAmount(&terminalData) == TERMINAL_OK
		 && isBelowMaxAmount(&terminalData)== TERMINAL_OK
		 && setMaxAmount(&terminalData, 10000.0) == TERMINAL_OK){

			if(	recieveTransactionData(&transcationData) == APPROVED
			&& isValidAccount(&myCardData) == SERVER_OK
			&& isBlockedAccount() == SERVER_OK
			&& isAmountAvailable(&terminalData) == SERVER_OK ){

				saveTransaction(&transcationData);
				listSavedTransactions();
			}
			else printf("Server Error");
		}
		else printf("Wrong Transaction Data");
	}
	else printf("Wrong Card Data");

}
