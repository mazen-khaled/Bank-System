/*
 ============================================================================
 Name        : C_Project.c
 Author      : Mazen Khaled
 Copyright   : Your copyright notice
 Description : C-Project
 ============================================================================
 */

#include <stdio.h>
#include "Application\Application.h"

int main(void) {
	appStart();
	return 0;
}
