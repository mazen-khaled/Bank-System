/*
 ============================================================================
 Module      : Card.c
 Author      : Mazen Khaled
 Copyright   : Your copyright notice
 Description : C-Project
 ============================================================================
 */

#include <ctype.h>
#include "Card.h"

EN_cardError_t getCardHolderName(ST_cardData_t* cardData) {
	int count = 0;

	//Searching for the \0 (end of string)
	for (int x = 0; x <= 24; x++) {
		if (cardData->cardHolderName[x] != '\0')	count++;
		else break;
	}

	//Return the state of the (cardholder name)
	if (count >= 24 || count <= 20)
		return WRONG_NAME;
	else
		return CARD_OK;
}

EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData) {

	//Check the month and the year of expiry 2 digit then / then 2 digit then \0
	if(isdigit((cardData->cardExpirationDate[0])) && isdigit((cardData->cardExpirationDate[1])) &&
	   isdigit((cardData->cardExpirationDate[3])) && isdigit((cardData->cardExpirationDate[4])) &&
	   cardData->cardExpirationDate[2] == '/' && cardData->cardExpirationDate[5] == '\0')
	return CARD_OK;

	else return WRONG_EXP_DATE;
}

EN_cardError_t getCardPAN(ST_cardData_t* cardData) {
	int count = 0;

	//Searching for the \0 (end of string)
	for (int x = 0; x <= 19; x++) {
		if (cardData->primaryAccountNumber[x] != '\0')	count++;
		else break;
	}

	//Return the state of the (cardholder name)
	if (count > 19 || count < 16)
		return WRONG_PAN;
	else
		return CARD_OK;
}
